package org.example.Student.utility;

import java.util.Date;

public class DataUtility {
    private DataUtility() {}

    public static Date getCurrentDate(){
        return new Date();
    }
}
